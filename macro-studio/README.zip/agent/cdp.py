"""Chrome DevTools Protocol driver -- the web half of replay.

UI Automation is the right tool for desktop apps, but it hits a hard wall
on modern web pages: Chrome only exposes the *active* tab's accessibility
tree, and a site built out of custom widgets (BigSeller's nav tabs, for
one) hands us elements with no Invoke, Select, Toggle, or DoDefaultAction
pattern -- nothing UIA can click. The only fallback left on that side is a
physical mouse click, which defeats the whole point of background replay.

CDP sidesteps all of it. We talk to Chrome's own debugging endpoint over
HTTP + WebSocket and click the DOM node directly: custom widgets, icon
glyphs, wrapper elements, background tabs, no window focus needed. It's
local and free -- the same protocol DevTools itself uses, no API key, no
per-run cost, nothing leaving the machine.

The catch, stated plainly: since Chrome 136 the debugging port is refused
on the default user-data-dir, so CDP steps run against a Chrome started
with its own `--user-data-dir`. That's a separate profile, which means
signing in to a site once inside it. The session persists after that, so
it is a one-time cost.

Everything here is synchronous on purpose -- replay runs on a worker
thread, not an event loop, so `websockets.sync` fits it better than the
async client. Every function raises RuntimeError with a message written to
be shown to the user as-is; replay.py puts it straight into the step's
failure reason.
"""
from __future__ import annotations

import base64
import json
import os
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Optional

from websockets.sync.client import connect as ws_connect

from agent import actions

DEFAULT_PORT = 9222
DEFAULT_PROFILE_DIR = os.path.join(
    os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "MacroStudio", "ChromeProfile"
)
# One CDP round trip is near-instant on loopback; a call that needs longer
# than this is a page problem, not a transport problem.
_WS_TIMEOUT = 20.0


# -- endpoint plumbing -------------------------------------------------------
def _http_json(port: int, path: str, timeout: float = 3.0):
    with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=timeout) as resp:
        body = resp.read().decode("utf-8", "replace")
    return json.loads(body) if body.strip() else None


def is_running(port: int = DEFAULT_PORT) -> bool:
    """True if something is answering CDP on this port -- lets a launch
    step skip a redundant launch, and tells "Chrome isn't up" apart from
    "Chrome is up but that tab isn't there"."""
    try:
        _http_json(port, "/json/version", timeout=1.5)
        return True
    except Exception:
        return False


def launch(port: int = DEFAULT_PORT, user_data_dir: str = "", url: str = "",
           wait_seconds: float = 20.0) -> str:
    """Starts a debuggable Chrome, or reuses one already listening on the
    port. Returns a sentence saying which of the two happened."""
    if is_running(port):
        if url:
            open_tab(port, url)
            return f"Reused the Chrome already debugging on port {port}; opened {url}."
        return f"Reused the Chrome already debugging on port {port}."

    chrome = actions.find_chrome()
    if not chrome:
        raise RuntimeError(
            "Chrome wasn't found in its usual install locations. "
            "Install it from https://www.google.com/chrome/, or use a different step for this."
        )
    profile = user_data_dir or DEFAULT_PROFILE_DIR
    os.makedirs(profile, exist_ok=True)
    args = [
        chrome,
        f"--remote-debugging-port={port}",
        f"--user-data-dir={profile}",
        "--no-first-run",
        "--no-default-browser-check",
        # Chrome stops rendering a window it believes nobody can see, and
        # a page that isn't rendering doesn't update hover state -- so a
        # macro that worked in front failed the moment the window was
        # minimised or covered. These three keep it live regardless: no
        # occlusion detection, no throttling of a backgrounded window or
        # its renderer.
        "--disable-features=CalculateNativeWinOcclusion",
        "--disable-backgrounding-occluded-windows",
        "--disable-renderer-backgrounding",
    ]
    if url:
        args.append(url)
    subprocess.Popen(args)

    deadline = time.time() + wait_seconds
    while time.time() < deadline:
        if is_running(port):
            return f'Started Chrome on debugging port {port} with profile "{profile}".'
        time.sleep(0.3)
    raise RuntimeError(
        f"Chrome was launched but never answered on debugging port {port} within "
        f"{round(wait_seconds)}s. If a Chrome is already open on the same profile folder "
        f'("{profile}"), close it and try again -- one profile can only be used by one '
        "Chrome at a time."
    )


OFFSCREEN_LEFT = -32000


def _browser_socket(port: int) -> dict:
    version = _http_json(port, "/json/version") or {}
    ws_url = version.get("webSocketDebuggerUrl")
    if not ws_url:
        raise RuntimeError(f"Chrome on port {port} didn't offer a browser socket.")
    return {"webSocketDebuggerUrl": ws_url}


def _windows(port: int) -> list:
    """Every window of the debugging browser, as (windowId, bounds)."""
    sock = _browser_socket(port)
    seen, out = set(), []
    for page in list_pages(port):
        try:
            info = _send(sock, "Browser.getWindowForTarget", {"targetId": page.get("id")}, timeout=5)
        except RuntimeError:
            continue
        window_id = info.get("windowId")
        if window_id in seen:
            continue
        seen.add(window_id)
        out.append((window_id, info.get("bounds", {})))
    return out


def browser_window_handles(port: int = DEFAULT_PORT) -> list:
    """Top-level windows belonging to the debugging browser's processes.
    Same identification as browser_window_title, which is the only way to
    tell this Chrome from a normal one."""
    from agent import winapi

    pids = set()
    try:
        info = _send(_browser_socket(port), "SystemInfo.getProcessInfo", {}, timeout=5)
        for entry in info.get("processInfo", []) or []:
            pids.add(entry.get("id"))
    except Exception:
        return []
    handles = []
    for hwnd in winapi.enum_top_level_windows():
        if winapi.window_pid(hwnd) in pids and winapi.window_class_name(hwnd) == "Chrome_WidgetWin_1":
            if winapi.window_title(hwnd):
                handles.append(hwnd)
    return handles


def park_offscreen(port: int = DEFAULT_PORT, only_minimized: bool = False) -> int:
    """Un-minimises the browser's windows and parks them off the desktop.

    Minimised is the one state a macro cannot work in: Chrome marks the
    page hidden, rAF stops, and menus that mount through it never open --
    which reads as "the macro only works when I'm watching it". Off-screen
    keeps the window rendering in every sense that matters while staying
    just as far out of the way. Returns how many windows were moved.

    `only_minimized` is for the automatic pass at the start of a run: get
    the unusable state out of the way, but don't yank a window off-screen
    that the user deliberately left where they could watch it. The button
    parks everything, because that's what pressing it asks for."""
    from agent import winapi

    # Done through Win32 rather than Browser.setWindowBounds: a plain
    # restore hands the window the foreground, which is the thing we're
    # trying to avoid, and a maximised window ignores bounds changes
    # entirely, so parking it would silently do nothing.
    moved = 0
    for hwnd in browser_window_handles(port):
        minimized = winapi.is_minimized(hwnd)
        if only_minimized and not minimized:
            continue
        if not minimized and winapi.window_rect(hwnd)[0] <= -1000:
            continue  # already parked
        if minimized:
            winapi.restore_without_focus(hwnd)
        winapi.move_window(hwnd, OFFSCREEN_LEFT, 0, 1400, 950, to_back=True)
        moved += 1
    return moved


def show_windows(port: int = DEFAULT_PORT) -> int:
    """Brings parked windows back where they can be seen."""
    from agent import winapi

    shown = 0
    for hwnd in browser_window_handles(port):
        left = winapi.window_rect(hwnd)[0]
        if winapi.is_minimized(hwnd):
            winapi.restore_without_focus(hwnd)
        elif left > -1000:
            continue
        winapi.move_window(hwnd, 60, 60, 1400, 950, to_back=False)
        shown += 1
    return shown


def close_browser(port: int = DEFAULT_PORT, timeout: float = 10.0) -> str:
    """Quits the debugging Chrome.

    Browser.close is the graceful path -- Chrome writes its session out and
    exits the way it would on File > Exit, so the profile isn't left looking
    crashed and the next launch doesn't offer to restore tabs. Nothing here
    can reach a normal Chrome: this connects through the debugging port,
    which only the browser Macro Studio started is listening on."""
    if not is_running(port):
        return f"No Chrome was debugging on port {port} -- nothing to close."
    version = _http_json(port, "/json/version") or {}
    browser_ws = version.get("webSocketDebuggerUrl")
    if not browser_ws:
        raise RuntimeError(f"Chrome on port {port} didn't offer a browser socket to close it by.")
    try:
        _send({"webSocketDebuggerUrl": browser_ws}, "Browser.close", {}, timeout=5)
    except RuntimeError:
        pass  # it often drops the socket mid-reply; the wait below is the real check

    deadline = time.time() + timeout
    while time.time() < deadline:
        if not is_running(port):
            return f"Closed the Chrome on port {port}."
        time.sleep(0.3)
    raise RuntimeError(f"Chrome on port {port} was asked to close but is still answering.")


def list_pages(port: int = DEFAULT_PORT) -> list:
    try:
        targets = _http_json(port, "/json/list") or []
    except Exception:
        raise RuntimeError(
            f"Nothing is listening for CDP on port {port} -- put a "
            '"Launch Chrome (CDP)" step before this one, or fix the port.'
        )
    return [t for t in targets if t.get("type") == "page" and t.get("webSocketDebuggerUrl")]


def _settled_file(folder: Path, since: float, seen: dict) -> Optional[Path]:
    """The newest finished file in `folder`, or None if nothing is ready.

    Chrome writes to `name.pdf.crdownload` and renames on completion, so a
    partial file is easy to skip -- but a small one can appear complete
    while it is still being written, which is why a size has to repeat
    before it counts."""
    best = None
    for entry in folder.glob("*"):
        if not entry.is_file() or entry.suffix.lower() in (".crdownload", ".tmp"):
            continue
        try:
            stat = entry.stat()
        except OSError:
            continue
        if stat.st_mtime < since - 1 or not stat.st_size:
            continue
        if best is None or stat.st_mtime > best[1]:
            best = (entry, stat.st_mtime, stat.st_size)
    if best is None:
        return None
    entry, _, size = best
    if seen.get(str(entry)) == size:
        return entry
    seen[str(entry)] = size
    return None


def download_by_clicking(port: int, page: dict, folder: str, selector: str = "", text: str = "",
                         exact: bool = False, match_index: int = 0, timeout_ms: int = 60000,
                         hover_selector: str = "", hover_text: str = "",
                         hover_exact: bool = False) -> dict:
    """Clicks something that starts a download, and puts the file where the
    macro says.

    Chrome's download folder is browser UI -- the same wall as the print
    dialog -- so the only way to choose it is Browser.setDownloadBehavior.
    That override belongs to the connection that set it and dies with it,
    and every other call here opens a socket, sends one command and closes
    it: set the folder that way and the file lands in Downloads anyway,
    minutes later, with nothing to say why. So the socket stays open for
    the whole thing -- folder, click, and the wait for the file to finish
    being written -- and only then goes.

    The click has to be a real press for this to work at all. A page that
    starts a download from a synthetic event is refused by Chrome for
    want of a user gesture, which looks exactly like a click that missed."""
    if not folder:
        raise RuntimeError("No folder given for the download to go to.")
    target = Path(folder)
    if target.exists() and not target.is_dir():
        raise RuntimeError(f'"{folder}" is a file, not a folder.')
    target.mkdir(parents=True, exist_ok=True)
    deadline = time.time() + min(max(1000, timeout_ms), 600_000) / 1000.0

    def body(call):
        call("Browser.setDownloadBehavior", {"behavior": "allow", "downloadPath": str(target)})
        started = time.time()
        clicked = click(page, selector=selector, text=text, exact=exact,
                        timeout_ms=min(15000, timeout_ms), match_index=match_index,
                        hover_selector=hover_selector, hover_text=hover_text,
                        hover_exact=hover_exact)
        seen: dict = {}
        while time.time() < deadline:
            found = _settled_file(target, started, seen)
            if found is not None:
                return {"file": str(found), "label": clicked.get("label", ""),
                        "covered": bool(clicked.get("covered"))}
            time.sleep(0.4)
        raise RuntimeError(
            f'Clicked "{clicked.get("label") or selector or text}" but no file finished '
            f'downloading into "{target}" within {round(timeout_ms / 1000)}s.'
            + (" The click had to be dispatched rather than pressed, which Chrome refuses to"
               " start a download from -- something was covering the button."
               if clicked.get("covered") else ""))

    return _conversation(_browser_socket(port), body, timeout=30.0)


def open_tab(port: int, url: str) -> dict:
    """Opens a tab in the Chrome window that is already there.

    The step says "new tab", so it opens a tab -- Target.createTarget with
    newWindow off puts the page in the existing window rather than giving
    it one of its own.

    It has to be that window's *active* tab, and that is not a nicety. A
    background tab is hidden: visibilityState says so, and
    requestAnimationFrame never fires, which means any menu that mounts or
    animates through rAF -- ant's, and most component libraries' -- never
    opens, so nothing after the hover can be clicked. Being active inside
    its own window is what the renderer cares about; the window itself is
    not raised over whatever else the user is looking at."""
    version = _http_json(port, "/json/version") or {}
    browser_ws = version.get("webSocketDebuggerUrl")
    if browser_ws:
        try:
            result = _send({"webSocketDebuggerUrl": browser_ws}, "Target.createTarget",
                           {"url": url, "newWindow": False, "background": False}, timeout=10)
            target_id = result.get("targetId")
            if target_id:
                for page in list_pages(port):
                    if page.get("id") == target_id:
                        return page
                # Listed a moment too early; the id is enough to act on.
                return {"id": target_id, "url": url,
                        "webSocketDebuggerUrl": f"ws://127.0.0.1:{port}/devtools/page/{target_id}"}
        except RuntimeError:
            pass  # older Chrome, or those params unsupported -- fall through

    quoted = urllib.parse.quote(url, safe="")
    request = urllib.request.Request(f"http://127.0.0.1:{port}/json/new?{quoted}", method="PUT")
    try:
        with urllib.request.urlopen(request, timeout=8) as resp:
            return json.loads(resp.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"Chrome refused to open a new tab ({exc.code}).")


def find_page(port: int, match: str = "", timeout_ms: int = 0) -> dict:
    """Picks the tab to act on. An empty match takes the first page, which
    covers the common single-tab case; otherwise it is a case-insensitive
    substring test against the tab's URL and title -- the two things a
    person can see and type -- or a target id handed down from an earlier
    step in the same run. A timeout lets a step wait for a tab that a
    previous step's navigation is still opening."""
    deadline = time.time() + max(0, timeout_ms) / 1000.0
    exact_id = (match or "").strip()
    while True:
        pages = list_pages(port)
        needle = exact_id.lower()
        if not needle and pages:
            return pages[0]
        # A step that inherits the tab from earlier in the run passes a
        # target id, which survives navigation; a hand-typed match is a
        # URL or title fragment. Ids are checked first so they can't be
        # mistaken for a fragment that happens to match nothing.
        for page in pages:
            if page.get("id") == exact_id:
                return page
        for page in pages:
            haystack = f"{page.get('url', '')} {page.get('title', '')}".lower()
            if needle and needle in haystack:
                return page
        if time.time() >= deadline:
            if not pages:
                raise RuntimeError(f"Chrome is debugging on port {port} but has no open page tabs.")
            seen = ", ".join('"' + str(p.get("title", ""))[:40] + '"' for p in pages[:5])
            raise RuntimeError(f'No open tab matching "{match}". Open tabs: {seen}.')
        time.sleep(0.3)


def browser_window_title(port: int = DEFAULT_PORT) -> str:
    """The exact OS window title of the Chrome on this debugging port.

    Needed because ffmpeg's gdigrab matches a window by its full title,
    and this Chrome's title is whatever page it happens to be showing --
    not something anyone can type in advance, and not something that
    distinguishes it from a normal Chrome window either. The debugging
    port does distinguish it: ask Chrome which processes are its own,
    then find the top-level window belonging to one of them.

    Returns "" when nothing matches, which callers treat as "record the
    whole screen instead" rather than an error."""
    from agent import winapi  # local import: video/window concerns, not CDP's core

    pids = set()
    try:
        version = _http_json(port, "/json/version") or {}
        browser_ws = version.get("webSocketDebuggerUrl")
        if browser_ws:
            info = _send({"webSocketDebuggerUrl": browser_ws}, "SystemInfo.getProcessInfo", {}, timeout=5)
            for entry in info.get("processInfo", []) or []:
                if entry.get("type") in ("browser", "renderer", "gpu"):
                    pids.add(entry.get("id"))
    except Exception:
        pass
    if not pids:
        return ""

    best = ""
    for hwnd in winapi.enum_top_level_windows():
        if winapi.window_pid(hwnd) not in pids:
            continue
        if winapi.window_class_name(hwnd) != "Chrome_WidgetWin_1":
            continue
        title = winapi.window_title(hwnd)
        # Chrome keeps invisible helper windows around with the same
        # class; the one showing a page is the one with a real title.
        if title and (not best or len(title) > len(best)):
            best = title
    return best


def wait_for_new_page(port: int, known_ids, match: str = "", timeout_ms: int = 15000) -> dict:
    """Waits for a tab that isn't one of `known_ids` and returns it.

    Sites open a PDF, a print preview, or a report in a new tab, and the
    steps after that click mean it, not the tab they were on. Which tab is
    "new" can't be answered by URL or title -- there may be three tabs on
    the same site -- so it's answered by identity: everything the run has
    touched so far is known, and anything else appeared because of what
    just happened. A match fragment narrows it further when a click opens
    more than one."""
    known = set(known_ids or [])
    needle = (match or "").strip().lower()
    deadline = time.time() + max(0, timeout_ms) / 1000.0

    def is_content(page: dict) -> bool:
        # chrome://newtab and devtools windows count as tabs and appear at
        # exactly the wrong moment -- when Chrome was just launched, or when
        # a click opened the one we actually want. Following one produces a
        # blank PDF and a run that reports success.
        url = str(page.get("url", ""))
        return not url.startswith(("chrome://", "chrome-extension://", "devtools://", "edge://"))

    while True:
        fresh = [p for p in list_pages(port) if p.get("id") not in known and is_content(p)]
        for page in fresh:
            haystack = f"{page.get('url', '')} {page.get('title', '')}".lower()
            if not needle or needle in haystack:
                # Give it a moment to commit its first document, or the
                # steps after this one evaluate against about:blank.
                return wait_ready(port, page.get("id", ""), "", timeout_ms=min(8000, timeout_ms))
        if time.time() >= deadline:
            if fresh:
                raise RuntimeError(
                    f'{len(fresh)} new tab(s) opened but none matching "{match}".')
            raise RuntimeError(f"No new tab opened within {timeout_ms}ms.")
        time.sleep(0.3)


def activate_page(port: int, page: dict) -> str:
    """Puts a tab in front, so a person watching sees what the run is
    doing on it.

    Nothing else needs this: the steps drive a tab by id whether it is
    visible or buried. It exists for the times a page opens a tab of its
    own -- a print job, a preview -- and leaves the browser showing that
    while the run carries on somewhere else, out of sight.

    Two calls, because they answer different questions: activateTarget
    picks the tab within its window, bringToFront raises the window."""
    target_id = page.get("id", "")
    if not target_id:
        raise RuntimeError("That tab has no id to bring forward.")
    _send(_browser_socket(port), "Target.activateTarget", {"targetId": target_id})
    try:
        _send(page, "Page.bringToFront", {})
    except RuntimeError:
        # The tab is already the one showing; a window that refuses to be
        # raised is not a reason to fail the step.
        pass
    return page.get("url", "")


def close_page(port: int, target_id: str) -> None:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/json/close/{target_id}", timeout=5):
            pass
    except Exception as exc:
        raise RuntimeError(f"Couldn't close that tab: {exc}")


# -- one round trip ----------------------------------------------------------
def _send(page: dict, method: str, params: dict, timeout: float = _WS_TIMEOUT) -> dict:
    """Opens a socket, sends one command, waits for that command's reply.
    A fresh connection per call costs a few milliseconds on loopback and
    saves owning a long-lived socket across a replay that can pause, stop,
    or fail at any step."""
    ws_url = page.get("webSocketDebuggerUrl")
    if not ws_url:
        raise RuntimeError("That tab has no debugger socket -- it may have just closed.")
    try:
        with ws_connect(ws_url, open_timeout=5, close_timeout=2, max_size=None) as sock:
            sock.send(json.dumps({"id": 1, "method": method, "params": params}))
            deadline = time.time() + timeout
            while time.time() < deadline:
                message = json.loads(sock.recv(timeout=max(0.5, deadline - time.time())))
                if message.get("id") != 1:
                    continue
                if "error" in message:
                    raise RuntimeError(f"Chrome rejected {method}: {message['error'].get('message')}")
                return message.get("result", {})
    except RuntimeError:
        raise
    except Exception as exc:
        raise RuntimeError(f"CDP call {method} failed: {exc}")
    raise RuntimeError(f"CDP call {method} timed out after {round(timeout)}s.")


def _conversation(page: dict, body, timeout: float = _WS_TIMEOUT):
    """Runs several commands down ONE socket, handing `body` the call to
    do it with.

    `_send` opens a fresh connection per command, which is right for calls
    that stand alone. DOM node ids are not one of those: Chrome hands them
    out per connection, so a nodeId from `DOM.querySelector` means nothing
    to a `DOM.setFileInputFiles` sent down a different socket. Anything
    that passes an id from one command to the next shares a session."""
    ws_url = page.get("webSocketDebuggerUrl")
    if not ws_url:
        raise RuntimeError("That tab has no debugger socket -- it may have just closed.")
    try:
        socket = ws_connect(ws_url, open_timeout=5, close_timeout=2, max_size=None)
    except Exception as exc:
        raise RuntimeError(f"Could not open a debugger socket on that tab: {exc}")
    counter = {"n": 0}
    with socket as sock:
        def call(method: str, params: dict | None = None) -> dict:
            counter["n"] += 1
            msg_id = counter["n"]
            try:
                sock.send(json.dumps({"id": msg_id, "method": method, "params": params or {}}))
                deadline = time.time() + timeout
                while time.time() < deadline:
                    message = json.loads(sock.recv(timeout=max(0.5, deadline - time.time())))
                    if message.get("id") != msg_id:
                        continue
                    if "error" in message:
                        raise RuntimeError(f"Chrome rejected {method}: {message['error'].get('message')}")
                    return message.get("result", {})
            except RuntimeError:
                raise
            except Exception as exc:
                raise RuntimeError(f"CDP call {method} failed: {exc}")
            raise RuntimeError(f"CDP call {method} timed out after {round(timeout)}s.")

        return body(call)


def evaluate(page: dict, expression: str, timeout: float = _WS_TIMEOUT):
    """Runs JS in the page and returns its value. Promises are awaited, so
    the helpers below can poll with setTimeout and resolve when they're
    ready -- that's how waiting and retrying stay inside one round trip."""
    result = _send(page, "Runtime.evaluate", {
        "expression": expression,
        "awaitPromise": True,
        "returnByValue": True,
        "userGesture": True,
    }, timeout=timeout)
    if result.get("exceptionDetails"):
        detail = result["exceptionDetails"]
        text = (detail.get("exception") or {}).get("description") or detail.get("text") or "unknown error"
        raise RuntimeError(f"The page threw an error: {str(text).splitlines()[0]}")
    return (result.get("result") or {}).get("value")


# -- the JS side -------------------------------------------------------------
# Kept as a string rather than a separate asset so there's nothing extra to
# ship or keep in sync -- the whole driver is these few functions.
_JS_HELPERS = r"""
const __ms = {
  // Every document on the page: the real one, plus every shadow root
  // under it. Alibaba's workbench is 1100 custom elements deep and
  // document.querySelector sees none of it -- an order list with a search
  // box in it reports zero inputs and a blank innerText, which looks
  // exactly like a page that failed to load. Everything below queries
  // through here, so a shadow-DOM page behaves like any other.
  roots() {
    const out = [document];
    const walk = (root) => {
      for (const el of root.querySelectorAll("*")) {
        if (el.shadowRoot) {
          out.push(el.shadowRoot);
          walk(el.shadowRoot);
        }
      }
    };
    walk(document);
    return out;
  },
  queryAll(selector) {
    const out = [];
    for (const root of __ms.roots()) {
      try {
        out.push(...root.querySelectorAll(selector));
      } catch (err) { /* invalid selector: the caller falls back to the label */ }
    }
    return out;
  },
  query(selector) {
    return __ms.queryAll(selector)[0] || null;
  },
  visible(el) {
    const r = el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) return false;
    const s = getComputedStyle(el);
    return s.visibility !== "hidden" && s.display !== "none" && s.opacity !== "0";
  },
  // Deepest-wins: a page's clickable label usually sits inside several
  // containers that all report the same innerText, and clicking the
  // outermost one either misses or hits the wrong thing. The smallest
  // visible box still containing the text is the reliable pick.
  byText(text, exact) {
    const want = String(text).trim().toLowerCase();
    const out = [];
    for (const el of __ms.queryAll("*")) {
      // <html> and <body> hold every word on the page between them, and
      // "deepest wins" only sorts them last -- it doesn't stop them being
      // the answer when nothing else matched.
      if (el === document.documentElement || el === document.body) continue;
      if (!__ms.visible(el)) continue;
      const own = String(el.innerText || el.value || el.getAttribute("aria-label") || "").trim().toLowerCase();
      if (!own) continue;
      if (exact ? own === want : own.includes(want)) out.push(el);
    }
    out.sort((a, b) => {
      const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
      return (ra.width * ra.height) - (rb.width * rb.height);
    });
    return out;
  },
  // Selector and text together narrow each other: a site's nav opener is
  // one of a dozen elements sharing a class, and the text alone matches
  // badges and column headers elsewhere on the page. Either one alone
  // still works on its own terms.
  find(selector, text, exact) {
    if (!selector) return __ms.byText(text, exact);
    const els = __ms.queryAll(selector).filter(__ms.visible);
    if (text) {
      const want = String(text).trim().toLowerCase();
      const matches = els.filter((el) => {
        const own = String(el.innerText || el.value || el.getAttribute("aria-label") || "").trim().toLowerCase();
        return exact ? own === want : own.includes(want);
      });
      // A recorded selector describes the page as it looked that day:
      // class names change, a panel re-renders somewhere else in the tree,
      // a menu is open now that wasn't then. The label is the durable half
      // of the pair, so when the selector no longer finds anything, fall
      // back to it rather than failing a step the user can plainly see.
      if (matches.length) return matches;
      return __ms.byText(text, exact);
    }
    return els;
  },
  // A real pointer sequence, not just el.click() -- component libraries
  // listen for pointerdown/mousedown and ignore a bare click event, and
  // that is exactly the widget class UIA could not touch.
  click(el) {
    el.scrollIntoView({ block: "center", inline: "center" });
    const r = el.getBoundingClientRect();
    const x = r.left + r.width / 2, y = r.top + r.height / 2;
    const opts = { bubbles: true, cancelable: true, clientX: x, clientY: y, view: window };
    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
      const Ctor = type.startsWith("pointer") ? PointerEvent : MouseEvent;
      el.dispatchEvent(new Ctor(type, opts));
    }
    return { tag: el.tagName.toLowerCase(), label: String(el.innerText || "").trim().slice(0, 60) };
  },
  poll(fn, timeoutMs) {
    const started = Date.now();
    return new Promise((resolve) => {
      const tick = () => {
        const got = fn();
        if (got) return resolve(got);
        if (Date.now() - started >= timeoutMs) return resolve(null);
        setTimeout(tick, 150);
      };
      tick();
    });
  },
};
"""


def _js(body: str) -> str:
    return "(async () => {" + _JS_HELPERS + body + "})()"


def _locate(page: dict, selector: str, text: str, exact: bool, timeout_ms: int,
            match_index: int = 0) -> dict:
    """Scrolls the best match into view and returns where it sits, so the
    caller can aim real browser input at it.

    `hit` says whether that point currently resolves back to the element.
    A menu that is still fading in, or an overlay on top, makes the answer
    no -- and a click aimed there would land on whatever is underneath,
    which is worse than not clicking at all. The caller uses it to pick
    the safer path."""
    args = json.dumps({"selector": selector, "text": text, "exact": exact,
                       "timeout": timeout_ms, "index": max(0, match_index)})
    result = evaluate(page, _js(
        "const a = " + args + ";"
        "const el = await __ms.poll(() => __ms.find(a.selector, a.text, a.exact)[a.index] || null, a.timeout);"
        "if (!el) return { ok: false };"
        "el.scrollIntoView({ block: 'center', inline: 'center' });"
        "let r = el.getBoundingClientRect(), hit = false;"
        # Settle loop: animated menus report a moving rect for a frame or
        # two after they open, so re-measure until the point sticks.
        "for (let i = 0; i < 12 && !hit; i++) {"
        "  await new Promise((res) => setTimeout(res, 60));"
        "  r = el.getBoundingClientRect();"
        # elementFromPoint on the document returns the shadow *host*,
        # which contains() then disagrees with -- a shadow tree is a
        # separate tree, so a perfectly clickable element reports itself
        # covered. Each shadow root answers for its own contents.
        "  const scope = el.getRootNode();"
        "  const from = scope.elementFromPoint ? scope : document;"
        "  const at = from.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);"
        "  hit = !!at && (at === el || el.contains(at) || at.contains(el));"
        "}"
        "return { ok: true, hit, x: r.left + r.width / 2, y: r.top + r.height / 2,"
        "         tag: el.tagName.toLowerCase(), label: String(el.innerText || '').trim().slice(0, 60) };"
    ), timeout=max(_WS_TIMEOUT, timeout_ms / 1000.0 + 5))
    if not result or not result.get("ok"):
        what = f'selector "{selector}"' if selector else f'text "{text}"'
        if selector and text:
            what = f'selector "{selector}" with text "{text}"'
        if match_index:
            what += f" (match #{match_index + 1})"
        raise RuntimeError(f"Nothing matching {what} appeared on the page within {timeout_ms}ms.")
    return result


def drop_files(page: dict, paths, selector: str = "", text: str = "",
               exact: bool = False, timeout_ms: int = 10000, match_index: int = 0) -> dict:
    """Drops files onto an element, as if they were dragged from Explorer.

    The other way in is `upload_files`, which needs an `<input type=file>`
    in the page. Plenty of drop zones don't have one: the button beside
    them builds an input in JavaScript, clicks it to raise Windows' own
    picker, and never puts it in the document -- so there is nothing for a
    selector to find, and the only route left is the drop itself.

    Chrome will synthesise that: a drag carrying real paths, which the page
    receives as ordinary File objects on `dataTransfer.files`. It cannot
    tell this apart from a drag off the desktop. The three events go down
    one socket because a drag is a sequence, not three unrelated pokes."""
    paths = [str(p) for p in paths]
    if not paths:
        raise RuntimeError("No file given to drop.")
    spot = _locate(page, selector or "body", text, exact, timeout_ms, match_index)
    data = {"items": [], "files": paths, "dragOperationsMask": 1}

    def drag(call):
        for kind in ("dragEnter", "dragOver", "drop"):
            call("Input.dispatchDragEvent",
                 {"type": kind, "x": spot["x"], "y": spot["y"], "data": data})

    try:
        _conversation(page, drag)
    except RuntimeError as exc:
        # Worth naming: the parameter is behind a flag in some builds, and
        # "unknown command" tells you nothing about which command.
        raise RuntimeError(f"This Chrome would not accept a synthesised file drop ({exc}).")
    return {"tag": spot.get("tag"), "label": spot.get("label"), "names": paths}


def hover(page: dict, selector: str = "", text: str = "", exact: bool = False,
          timeout_ms: int = 8000, match_index: int = 0) -> dict:
    """Moves the browser's own pointer over an element.

    This is the one thing dispatching DOM events cannot fake: a menu that
    opens on CSS `:hover` ignores a synthetic mouseover, because the
    browser -- not the page -- decides what is hovered. CDP's Input domain
    drives that same internal pipeline, so the menu opens for real. It is
    still not the OS cursor: nothing moves on screen and the tab need not
    be focused or even frontmost."""
    spot = _locate(page, selector, text, exact, timeout_ms, match_index)
    _send(page, "Input.dispatchMouseEvent", {
        "type": "mouseMoved", "x": spot["x"], "y": spot["y"], "buttons": 0,
    })
    return spot


def click(page: dict, selector: str = "", text: str = "", exact: bool = False,
          timeout_ms: int = 8000, match_index: int = 0, button: str = "left",
          hover_selector: str = "", hover_text: str = "", hover_exact: bool = False) -> dict:
    """Clicks the best match, retrying until timeout -- a page still
    rendering is the normal case right after a navigation, not something
    worth failing a run over.

    `button` may be "right", which fires the page's own contextmenu
    handling. Worth knowing what that does and doesn't reach: a site's
    custom right-click menu is part of the page and works normally, while
    Chrome's own grey menu (Save image as, Inspect) is drawn by the
    browser, not the page, and nothing here can click an entry in it."""
    spot = _locate_reopening(page, selector, text, exact, timeout_ms, match_index,
                             hover_selector, hover_text, hover_exact)
    if not spot.get("hit"):
        # The point doesn't resolve back to the element -- something is
        # over it, or it is still moving. Dispatch on the node itself.
        return dict(_dispatch_click(page, selector, text, exact, button, match_index), covered=True)
    try:
        # Browser-level input, not a dispatched DOM event: it carries
        # isTrusted, it moves the pointer first (so hover state settles
        # before the press), and sites that gate on either one behave the
        # way they do for a person. No OS cursor is involved.
        button = "right" if str(button).lower().startswith("r") else "left"
        pressed = 2 if button == "right" else 1  # CDP's buttons bitmask
        common = {"x": spot["x"], "y": spot["y"], "button": button, "clickCount": 1}
        _send(page, "Input.dispatchMouseEvent", {"type": "mouseMoved", "buttons": 0, **common})
        _send(page, "Input.dispatchMouseEvent", {"type": "mousePressed", "buttons": pressed, **common})
        _send(page, "Input.dispatchMouseEvent", {"type": "mouseReleased", "buttons": 0, **common})
        spot["button"] = button
        return spot
    except RuntimeError:
        # Some pages tear down and rebuild between locate and press; the
        # DOM-event path doesn't depend on coordinates staying valid.
        return dict(_dispatch_click(page, selector, text, exact, button, match_index), covered=True)


def _locate_reopening(page: dict, selector: str, text: str, exact: bool, timeout_ms: int,
                      match_index: int, hover_selector: str, hover_text: str,
                      hover_exact: bool) -> dict:
    """Finds the target, re-opening the menu it lives in on every attempt.

    A dropdown item is in the DOM whether or not the menu is open -- ant
    just marks the panel hidden and gives it no size -- so "is it there"
    and "can it be clicked" are different questions, and the second one
    depends on where the pointer happens to be. Hovering once before the
    click isn't enough: any re-render that moves the trigger out from
    under the pointer closes the menu again, which is exactly why such a
    step works one run and fails the next. Re-hovering each attempt turns
    that race into a retry."""
    if not (hover_selector or hover_text):
        return _locate(page, selector, text, exact, timeout_ms, match_index)

    # ">>" separates the levels of a nested menu -- "Bulk Print >> Print
    # Pick List" -- because a submenu only exists while its parent is
    # hovered, so re-opening means walking the whole chain again, not just
    # the last hop.
    selectors = [part.strip() for part in str(hover_selector).split(">>")]
    texts = [part.strip() for part in str(hover_text).split(">>")]
    levels = max(len(selectors), len(texts))
    chain = [(selectors[i] if i < len(selectors) else "",
              texts[i] if i < len(texts) else "") for i in range(levels)]

    deadline = time.time() + max(1000, timeout_ms) / 1000.0
    attempt_ms = 1500
    last: Exception = RuntimeError("Never looked for the target.")
    while True:
        try:
            for level_selector, level_text in chain:
                if not (level_selector or level_text):
                    continue
                hover(page, selector=level_selector, text=level_text, exact=hover_exact, timeout_ms=3000)
                time.sleep(0.35)  # menus animate open; measuring mid-animation finds nothing
        except RuntimeError as exc:
            last = exc
        try:
            return _locate(page, selector, text, exact, attempt_ms, match_index)
        except RuntimeError as exc:
            last = exc
        if time.time() >= deadline:
            raise last
        time.sleep(0.2)


def _dispatch_click(page: dict, selector: str, text: str, exact: bool,
                    button: str = "left", match_index: int = 0) -> dict:
    # The match number has to come along. This path is where a covered or
    # still-moving target lands, and falling back to the first match here
    # means "the second View details" quietly becomes "the first" -- a
    # click that succeeds on the wrong row, which is worse than a miss.
    args = json.dumps({"selector": selector, "text": text, "exact": exact,
                       "index": max(0, int(match_index or 0)),
                       "right": str(button).lower().startswith("r")})
    result = evaluate(page, _js(
        "const a = " + args + ";"
        "const el = __ms.find(a.selector, a.text, a.exact)[a.index] || null;"
        "if (!el) return { ok: false };"
        "if (a.right) {"
        "  const r = el.getBoundingClientRect();"
        "  const o = { bubbles: true, cancelable: true, button: 2, buttons: 2,"
        "              clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, view: window };"
        "  el.dispatchEvent(new MouseEvent('mousedown', o));"
        "  el.dispatchEvent(new MouseEvent('mouseup', o));"
        "  el.dispatchEvent(new MouseEvent('contextmenu', o));"
        "  return { ok: true, tag: el.tagName.toLowerCase(), button: 'right',"
        "           label: String(el.innerText || '').trim().slice(0, 60) };"
        "}"
        # An anchor's own click() follows its href even when a dispatched
        # event chain doesn't, so prefer it when there is one.
        "if (el.tagName === 'A' && el.getAttribute('href')) {"
        "  const info = { tag: 'a', label: String(el.innerText || '').trim().slice(0, 60) };"
        "  el.click();"
        "  return Object.assign({ ok: true }, info);"
        "}"
        "return Object.assign({ ok: true }, __ms.click(el));"
    ))
    if not result or not result.get("ok"):
        what = f'selector "{selector}"' if selector else f'text "{text}"'
        raise RuntimeError(f"Nothing matching {what} could be clicked on the page.")
    return result


def type_text(page: dict, selector: str, value: str, submit: bool = False) -> dict:
    """Puts the value in the box, and optionally presses Enter on it.

    The Enter is a real key through the browser, not `form.requestSubmit()`.
    Calling that goes straight to the form's native submission and skips
    the page's own keydown handler -- so a single-page app that would have
    filtered a list in place instead reloads the whole document, losing
    the search and (on a site that re-checks the session) landing on the
    login page. Nothing fails: the box gets the value, the step reports
    success, and every step after it works on the unfiltered list, taking
    the top row every time. A pressed key is what a person does, and it
    leaves the page free to preventDefault the way it means to."""
    args = json.dumps({"selector": selector, "value": value})
    result = evaluate(page, _js(
        "const a = " + args + ";"
        "const el = __ms.query(a.selector);"
        "if (!el) return { ok: false };"
        "el.focus();"
        # React and friends track the last value they set themselves, so
        # going through the native setter is what makes them notice.
        "const d = Object.getOwnPropertyDescriptor(el.constructor.prototype, 'value');"
        "if (d && d.set) d.set.call(el, a.value); else el.value = a.value;"
        "el.dispatchEvent(new Event('input', { bubbles: true }));"
        "el.dispatchEvent(new Event('change', { bubbles: true }));"
        "return { ok: true };"
    ))
    if not result or not result.get("ok"):
        raise RuntimeError(f'No element matched selector "{selector}" to type into.')
    if submit:
        for kind in ("rawKeyDown", "char", "keyUp"):
            _send(page, "Input.dispatchKeyEvent", {
                "type": kind, "key": "Enter", "code": "Enter", "text": "\r",
                "unmodifiedText": "\r", "windowsVirtualKeyCode": 13, "nativeVirtualKeyCode": 13,
            })
    return result


# Marks the one input the files are going to, so the DOM-domain lookup
# that follows lands on that exact node instead of repeating the guess.
_UPLOAD_MARK = "data-macro-studio-upload"


def upload_files(page: dict, paths: list, selector: str = "", timeout_ms: int = 10000,
                 match_index: int = 0) -> dict:
    """Hands files straight to a file input -- no file picker ever opens.

    A page's upload control is almost never the input itself: the input is
    `display:none` behind a styled button or a label. Clicking that button
    opens Windows' own Open dialog, and driving a dialog means typing a
    path into a window that appears whenever it appears, which is the part
    that breaks. Setting the input's file list over CDP skips the dialog
    entirely, so there is nothing left to race.

    The lookup deliberately doesn't go through the visible-element finder:
    a hidden input is the normal case here, not a broken one. Whatever the
    selector matches is resolved to the file input it stands for -- the
    element itself, one inside it, or the one a `<label for>` points at."""
    if not paths:
        raise RuntimeError("No file given to upload.")
    selector = selector or "input[type=file]"
    args = json.dumps({"selector": selector, "timeout": max(0, timeout_ms),
                       "index": max(0, match_index), "mark": _UPLOAD_MARK})
    found = evaluate(page, _js(
        "const a = " + args + ";"
        "const all = () => __ms.queryAll(a.selector);"
        "const els = await __ms.poll(() => { const l = all(); return l.length > a.index ? l : null; }, a.timeout);"
        "if (!els) return { ok: false };"
        "let el = els[a.index];"
        "const isFile = (n) => !!n && n.tagName === 'INPUT' && n.type === 'file';"
        "if (!isFile(el)) {"
        "  const label = el.closest('label');"
        "  let found = el.querySelector('input[type=file]')"
        "    || (el.htmlFor ? document.getElementById(el.htmlFor) : null)"
        "    || (label ? label.control : null);"
        # A styled button and the real input are usually siblings inside the
        # same small wrapper, so a couple of levels up is worth a look. It
        # stops short of <body> deliberately: from there every element on the
        # page "contains" every input, and the step would attach the file to
        # whichever one happened to be first.
        "  let up = el.parentElement;"
        "  for (let i = 0; !isFile(found) && i < 3 && up && up.tagName !== 'BODY' && up.tagName !== 'HTML'; i++) {"
        "    found = up.querySelector('input[type=file]');"
        "    up = up.parentElement;"
        "  }"
        "  el = found;"
        "}"
        "if (!isFile(el)) return { ok: false, wrong: true };"
        "__ms.queryAll('[' + a.mark + ']').forEach((n) => n.removeAttribute(a.mark));"
        "el.setAttribute(a.mark, '1');"
        "return { ok: true, multiple: !!el.multiple };"
    ), timeout=max(_WS_TIMEOUT, timeout_ms / 1000.0 + 5))
    if not found or not found.get("ok"):
        if found and found.get("wrong"):
            raise RuntimeError(f'"{selector}" matched something on the page, but it is not an upload '
                               "field and doesn't contain one.")
        raise RuntimeError(f'No upload field matching "{selector}" appeared within {timeout_ms}ms.')
    def attach(call):
        # By object handle rather than by node id: DOM.querySelector does
        # not reach into a shadow root, and on a page built out of custom
        # elements the input is always inside one. Evaluating for the
        # marked element hands back the node itself, which
        # DOM.setFileInputFiles takes just as happily -- and the handle is
        # only valid on this connection, which is why both calls share it.
        found = call("Runtime.evaluate", {
            "expression": _js("return __ms.query('[" + _UPLOAD_MARK + "]');"),
            "awaitPromise": True,
        })
        node = (found.get("result") or {}).get("objectId")
        if not node:
            raise RuntimeError("The upload field went away before the files could be attached.")
        # Chrome dispatches the field's own input and change events for
        # this, which is what starts the upload -- the page can't tell the
        # difference between this and someone picking the file by hand.
        call("DOM.setFileInputFiles", {"objectId": node, "files": [str(p) for p in paths]})

    try:
        if len(paths) > 1 and not found.get("multiple"):
            raise RuntimeError(f"That upload field takes one file at a time, and {len(paths)} were given.")
        _conversation(page, attach)
        names = evaluate(page, _js(
            "const el = __ms.query('[" + _UPLOAD_MARK + "]');"
            "return el && el.files ? [...el.files].map((f) => f.name) : [];"
        )) or []
    finally:
        try:
            evaluate(page, _js(
                "__ms.queryAll('[" + _UPLOAD_MARK + "]')"
                "  .forEach((n) => n.removeAttribute('" + _UPLOAD_MARK + "'));"
                "return true;"
            ))
        except RuntimeError:
            pass  # the mark is inert, and the page may have navigated away
    return {"names": names}


def wait_for(page: dict, selector: str = "", text: str = "", exact: bool = False,
             timeout_ms: int = 10000) -> dict:
    args = json.dumps({"selector": selector, "text": text, "exact": exact, "timeout": timeout_ms})
    result = evaluate(page, _js(
        "const a = " + args + ";"
        "const el = await __ms.poll(() => __ms.find(a.selector, a.text, a.exact)[0] || null, a.timeout);"
        "return el ? { ok: true, label: String(el.innerText || '').trim().slice(0, 60) } : { ok: false };"
    ), timeout=max(_WS_TIMEOUT, timeout_ms / 1000.0 + 5))
    if not result or not result.get("ok"):
        what = f'selector "{selector}"' if selector else f'text "{text}"'
        raise RuntimeError(f"{what} never appeared within {timeout_ms}ms.")
    return result


def wait_gone(page: dict, selector: str = "", text: str = "", exact: bool = False,
              timeout_ms: int = 10000) -> dict:
    """Waits for something to stop being on the page.

    The other half of waiting. A panel that closes on an animation is
    still in the document, and still the answer to "is it open?", for a
    few hundred milliseconds after the click that dismissed it -- long
    enough for the next step to open the same one again, or to be told
    the thing it wants is already there when what it can see is the last
    one on its way out. Absence is what says the page is ready for the
    next thing, and nothing else does."""
    args = json.dumps({"selector": selector, "text": text, "exact": exact, "timeout": timeout_ms})
    result = evaluate(page, _js(
        "const a = " + args + ";"
        "const gone = await __ms.poll(() => (__ms.find(a.selector, a.text, a.exact).length ? null : true), a.timeout);"
        "return { ok: !!gone };"
    ), timeout=max(_WS_TIMEOUT, timeout_ms / 1000.0 + 5))
    if not result or not result.get("ok"):
        what = f'selector "{selector}"' if selector else f'text "{text}"'
        raise RuntimeError(f"{what} was still on the page after {timeout_ms}ms.")
    return result


def read_text(page: dict, selector: str) -> str:
    args = json.dumps({"selector": selector})
    result = evaluate(page, _js(
        "const a = " + args + ";"
        "const el = __ms.query(a.selector);"
        "return el ? { ok: true, value: String(el.innerText || el.value || '').trim() } : { ok: false };"
    ))
    if not result or not result.get("ok"):
        raise RuntimeError(f'No element matched selector "{selector}" to read.')
    return result.get("value", "")


# Errors that mean "the page moved under us", not "this failed". A login
# redirect or an SPA route change mid-call produces exactly these, and the
# right response is to re-resolve the tab and try again, not to fail a run.
_TRANSIENT = (
    "execution context was destroyed",
    "inspected target navigated",
    "cannot find context",
    "no execution context",
    "target closed",
)


def _is_transient(exc: Exception) -> bool:
    text = str(exc).lower()
    return any(marker in text for marker in _TRANSIENT)


def through_navigation(port: int, page: dict, timeout_ms: int, call):
    """Runs `call(page)`, re-resolving the tab and retrying whenever the
    page navigates out from under it, until the step's own timeout. The
    tab is re-found by target id because that survives navigation."""
    deadline = time.time() + max(1000, timeout_ms) / 1000.0
    target_id = page.get("id", "")
    last: Exception = RuntimeError("The page kept navigating; nothing ran to completion.")
    while time.time() < deadline:
        try:
            return call(page)
        except RuntimeError as exc:
            if not _is_transient(exc):
                raise
            last = exc
            time.sleep(0.4)
            refreshed = next((p for p in list_pages(port) if p.get("id") == target_id), None)
            if refreshed:
                page = refreshed
    raise last


def wait_ready(port: int, target_id: str, expect_url: str = "", timeout_ms: int = 20000) -> dict:
    """Blocks until the tab has actually committed and finished loading
    the page we asked for, and returns its refreshed entry.

    This matters more than it looks. A tab opened by /json/new starts on
    about:blank and navigates a moment later; JS evaluated in that window
    runs in the *old* document's execution context, which the navigation
    then throws away -- so a poll started there waits out its whole
    timeout against a document that will never gain the content. Re-reading
    the target list each pass (a target id survives navigation, its URL
    does not) is what tells us the new document is the live one."""
    deadline = time.time() + max(0, timeout_ms) / 1000.0
    expect = (expect_url or "").strip().lower()
    last = None
    while True:
        for entry in list_pages(port):
            if entry.get("id") != target_id:
                continue
            last = entry
            url = str(entry.get("url", "")).lower()
            committed = url not in ("", "about:blank") and (not expect or _same_page(url, expect))
            if committed:
                try:
                    if evaluate(entry, "document.readyState", timeout=5) in ("interactive", "complete"):
                        return entry
                except RuntimeError:
                    pass  # context swapped mid-check; next pass sees the new one
            break
        if time.time() >= deadline:
            return last or find_page(port, "")
        time.sleep(0.25)


def _same_page(url: str, expect: str) -> bool:
    """Substring either way: the browser normalizes what we asked for
    (adds a scheme, a trailing slash, drops a default port) and sites
    redirect, so an exact comparison would reject perfectly good loads."""
    url, expect = url.rstrip("/"), expect.rstrip("/")
    return url.startswith(expect) or expect.startswith(url) or expect in url


# Paper sizes in inches, the unit Page.printToPDF speaks.
PAPER_SIZES = {
    "A4": (8.27, 11.69),
    "A3": (11.69, 16.54),
    "A5": (5.83, 8.27),
    "Letter": (8.5, 11.0),
    "Legal": (8.5, 14.0),
    "Tabloid": (11.0, 17.0),
}


def wait_loaded(page: dict, quiet_ms: int = 800, timeout_ms: int = 30000,
                min_ms: int = 0) -> dict:
    """Waits for the page to stop loading, not merely to exist.

    readyState alone answers "did the HTML arrive", which for anything that
    assembles itself from XHR is the wrong question -- a print view is
    "complete" while its table is still empty. So this also watches the
    resource list and waits for it to stop growing for a quiet stretch,
    which is what a person means by "wait for it to finish".

    Quiet has one blind spot it cannot reason its way out of: a page that
    has not started yet looks exactly like one that has finished. If the
    content arrives on a timer rather than a request, set `min_ms` to hold
    for at least that long first -- or better, wait for the content itself
    with a wait-for step, which is the only check that knows the
    difference."""
    args = json.dumps({"quiet": max(100, quiet_ms), "timeout": max(500, timeout_ms),
                       "min": max(0, min_ms)})
    result = evaluate(page, _js(
        "const a = " + args + ";"
        "const started = Date.now();"
        # Resources alone miss content that arrives on a timer -- a print
        # view that swaps "Loading..." for its table fetches nothing. So
        # watch the DOM as well and call it settled only when both have
        # been still for the quiet stretch.
        "let mutations = 0;"
        "const observer = new MutationObserver((records) => { mutations += records.length; });"
        "observer.observe(document.documentElement, { childList: true, subtree: true,"
        "                                             characterData: true, attributes: true });"
        "let count = -1, seenMutations = -1, since = Date.now();"
        "try {"
        "  while (Date.now() - started < a.timeout) {"
        "    const now = performance.getEntriesByType('resource').length;"
        "    if (now !== count || mutations !== seenMutations) {"
        "      count = now; seenMutations = mutations; since = Date.now();"
        "    }"
        "    const held = Date.now() - started >= a.min;"
        "    const quiet = Date.now() - since >= a.quiet;"
        # 'interactive' means the document is parsed and usable; only
        # subresources are outstanding, and this page has been still for
        # the quiet stretch regardless of what they are doing.
        "    const usable = document.readyState === 'complete' || document.readyState === 'interactive';"
        "    if (held && usable && quiet) {"
        "      return { ok: true, resources: now, mutations: mutations,"
        "               waited: Date.now() - started, state: document.readyState };"
        "    }"
        "    await new Promise((r) => setTimeout(r, 150));"
        "  }"
        "  return { ok: false, resources: count, mutations: mutations,"
        "           waited: Date.now() - started, state: document.readyState };"
        "} finally { observer.disconnect(); }"
    ), timeout=max(_WS_TIMEOUT, timeout_ms / 1000.0 + 10))
    if not result or not result.get("ok"):
        state = (result or {}).get("state", "unknown")
        raise RuntimeError(
            f"The page never stopped changing in {timeout_ms}ms (readyState {state}). "
            "Give it a longer timeout, or wait for something on it instead."
        )
    return result


def is_pdf_document(page: dict) -> bool:
    """Chrome shows a PDF inside a viewer of its own. Printing that tab
    prints the viewer, which is not the document anyone wanted."""
    url = str(page.get("url", "")).lower().split("?")[0]
    if url.endswith(".pdf"):
        return True
    try:
        return bool(evaluate(page, "document.contentType === 'application/pdf'", timeout=5))
    except RuntimeError:
        return False


def save_pdf_document(page: dict, output_path: str, timeout: float = 120.0) -> str:
    """Downloads the PDF a tab is displaying, bytes intact.

    Fetched from inside the page so it carries the session that was allowed
    to open it in the first place -- a login-gated report fetched any other
    way comes back as a login page."""
    data = evaluate(page, _js(
        "const res = await fetch(location.href, { credentials: 'include' });"
        "if (!res.ok) return { ok: false, status: res.status };"
        "const buf = new Uint8Array(await res.arrayBuffer());"
        "let bin = '';"
        "for (let i = 0; i < buf.length; i += 8192) {"
        "  bin += String.fromCharCode.apply(null, buf.subarray(i, i + 8192));"
        "}"
        "return { ok: true, b64: btoa(bin), bytes: buf.length };"
    ), timeout=timeout)
    if not data or not data.get("ok"):
        raise RuntimeError(f"Couldn't download that PDF (HTTP {(data or {}).get('status', '?')}).")
    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(base64.b64decode(data["b64"]))
    return str(target)


def print_to_pdf(page: dict, output_path: str, landscape: bool = False, paper: str = "A4",
                 scale: float = 1.0, background: bool = False, margin_inches: float = 0.4,
                 timeout: float = 90.0) -> str:
    """Saves the page as a PDF, straight to a path we choose.

    Chrome's Ctrl+P dialog -- destination, layout, folder picker -- is
    browser UI, not page content: no click can reach it, from here or
    anywhere else. Page.printToPDF is the same rendering path that dialog
    uses, minus the dialog, so "print, save as PDF, switch to landscape,
    pick a folder" becomes arguments instead of five clicks nobody can
    automate. It also means the file lands where the macro says rather
    than wherever the last download went.

    `background` is off by default, matching the tick Chrome's own dialog
    leaves clear. An app screen usually paints its page grey; with
    backgrounds on, every inch of paper the content doesn't cover comes out
    as a grey slab. Images and inline colour print either way -- this only
    governs CSS backgrounds."""
    if is_pdf_document(page):
        return save_pdf_document(page, output_path)

    width, height = PAPER_SIZES.get(str(paper), PAPER_SIZES["A4"])
    margin = max(0.0, float(margin_inches))
    params = {
        "landscape": bool(landscape),
        "printBackground": bool(background),
        "scale": max(0.1, min(float(scale or 1.0), 2.0)),
        "paperWidth": width,
        "paperHeight": height,
        "marginTop": margin,
        "marginBottom": margin,
        "marginLeft": margin,
        "marginRight": margin,
        "preferCSSPageSize": False,
    }
    result = _send(page, "Page.printToPDF", params, timeout=timeout)
    data = result.get("data")
    if not data:
        raise RuntimeError("Chrome produced no PDF data for that page.")

    target = Path(output_path)
    if target.is_dir() or output_path.endswith(("\\", "/")):
        raise RuntimeError(f'"{output_path}" is a folder -- give the full file name to save as.')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(base64.b64decode(data))
    return str(target)


def reload(page: dict, ignore_cache: bool = False, settle_ms: int = 1200) -> str:
    """Reloads the tab and waits for the new document to be the live one.

    `ignore_cache` is the Ctrl+Shift+R of the pair -- worth reaching for
    when a page is showing yesterday's data because something cached it,
    and worth leaving alone otherwise, since a cold reload of a heavy app
    screen is several seconds slower."""
    url = page.get("url", "")
    _send(page, "Page.reload", {"ignoreCache": bool(ignore_cache)})
    time.sleep(max(0, settle_ms) / 1000.0)
    return url


def navigate(page: dict, url: str, settle_ms: int = 1200) -> None:
    _send(page, "Page.navigate", {"url": url})
    time.sleep(max(0, settle_ms) / 1000.0)
